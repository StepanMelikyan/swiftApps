
import UIKit

final class ViewController2: UIViewController {
    private var label: UILabel = {
        let label = UILabel()
        label.text = "Авторизация"
        label.textAlignment = .center
        label.backgroundColor = .gray
        label.textColor = .white
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .gray
        title = "Вы успешно вошли"
    }
    
    private func setupViews() {
        // Обязательно добавляем сабвью на экран
        view.addSubview(label)
  
        
        //  Констрейнты настраиваем только ПОСЛЕ того, как добавим сабвью на экран
        setupConstraints()
    }
    
    
    // Настравиваем констрейнт
    private func setupConstraints() {
        label.translatesAutoresizingMaskIntoConstraints = false
 
        
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.widthAnchor.constraint(equalToConstant: view.frame.size.width/2),
            label.heightAnchor.constraint(equalToConstant: view.frame.size.width/8),
  
        ])
    }
}
