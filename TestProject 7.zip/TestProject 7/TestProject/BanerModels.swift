
import Foundation


struct BanerModels: Decodable {
    var copyright: Baner
    enum CodingKeys: String, CodingKey {
        case copyright = "copyright"
    }
}

struct Baner: Decodable {
    let text: String
    let url: String
    
    enum CodingKeys: String, CodingKey {
        case text = "text"
        case url = "url"
        
    }
}

