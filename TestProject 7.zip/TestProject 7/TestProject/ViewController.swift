

import UIKit
import WebKit


//
class ViewController: UIViewController {
    private let networkService = NetworkService()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        tap()

        }
        private func tap() {
            
            let tab1 = UINavigationController(rootViewController: ArrivalView())
            let tab2 = UINavigationController(rootViewController: DepartureView())
      
            tab1.tabBarItem.title = "Прилет"
            tab2.tabBarItem.title = "Вылет"
      
            let controllers = [tab1, tab2]
            let tabBarController = UITabBarController()
            tabBarController.viewControllers = controllers
            
            guard let firstScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let firstWindow = firstScene.windows.first else {
                return
            }

            firstWindow.rootViewController =  tabBarController
        }
    }
