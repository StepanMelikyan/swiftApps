
import UIKit

final class ArrivalView: UITableViewController {
    
    private let networkService = NetworkService()
    private var models: [Arrivals] = []
    private var mod: Baner? = nil
    private let banerView = BanerView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Прилет"
        view.backgroundColor = .white
        tableView.backgroundColor = .white
        navigationController?.navigationBar.tintColor = .black
        navigationController?.navigationBar.barTintColor = .white
        
        tableView.register(CellArrival.self, forCellReuseIdentifier: "ArrivalCell")
        networkService.getArrivals  { [weak self] arrivals in
            self?.models = arrivals
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
        
        networkService.getBaners { Baner in
            DispatchQueue.main.async {
                self.banerView.setData(text: Baner.text, URL: Baner.url)
            }
        }
        
        tableView.addSubview(banerView)
        setupConstraints()
        tableView.dataSource = self
        tableView.delegate = self
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        models.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ArrivalCell", for: indexPath) as? CellArrival else {
            return UITableViewCell()
        }
        let model = models[indexPath.row]
        cell.updateCell(model: model)
        return cell
    }
    private func setupConstraints() {
        banerView.translatesAutoresizingMaskIntoConstraints = false

        if #available(iOS 11.0, *) {
            let safeArea = view.safeAreaLayoutGuide
            NSLayoutConstraint.activate([
                banerView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
                banerView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),
                banerView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor),
                banerView.heightAnchor.constraint(equalToConstant: 100)
            ])
        } else {
            NSLayoutConstraint.activate([
                banerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                banerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                banerView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
                banerView.heightAnchor.constraint(equalToConstant: 100)
            ])

        }
    }
    
}
