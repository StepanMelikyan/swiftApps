import UIKit

class BanerView: UIView {
    
    
    func setData(text: String, URL: String) {
        infoLabel.text = text
        linkLabel.text = URL
    }
    
    
    let infoLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    let linkLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    private func setupUI() {
        backgroundColor = .yellow
        
        // Добавьте infoLabel и linkLabel на баннер
        addSubview(infoLabel)
        addSubview(linkLabel)
        
        infoLabel.translatesAutoresizingMaskIntoConstraints = false
        linkLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            infoLabel.topAnchor.constraint(equalTo: topAnchor, constant: 25),
            infoLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            linkLabel.topAnchor.constraint(equalTo: topAnchor, constant: 50),
            linkLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            
        ])
    }
}

