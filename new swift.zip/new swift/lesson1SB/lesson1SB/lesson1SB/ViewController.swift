//
//  ViewController.swift
//  lesson1SB
//
//  Created by Stepan on 26.06.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

