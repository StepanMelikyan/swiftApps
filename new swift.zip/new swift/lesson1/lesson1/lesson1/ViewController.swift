

import UIKit

class ViewController: UIViewController {
    
    // 1 способ создания и настройки элемента
    private var label: UILabel = {
        let label = UILabel()
        label.text = "Авторизация"
        label.textAlignment = .center
        label.backgroundColor = .gray
        label.textColor = .white
        return label
    }()
    
    private var log: UITextField {
        let log = UITextField(frame: CGRect(x: 30, y: 350, width: 300, height: 30))
        log.text = "Логин: "
        log.textAlignment = .left
        log.backgroundColor = .gray
        log.textColor = .white
        return log
    }
    
    private var pass: UITextField {
        let pass = UITextField(frame: CGRect(x: 30, y: 450, width: 300, height: 30))
        pass.text = "Пароль: "
        pass.textAlignment = .left
        pass.backgroundColor = .gray
        pass.textColor = .white
        return pass
    }
  
    private var button = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        makeButton()
        setupViews()
        
        //добавление фото
        
        let ImageView = UIImageView(frame: CGRect(x: 168, y: 150, width: 50, height: 50))
        ImageView.image = UIImage(systemName: "globe")
        self.view.addSubview(ImageView)
        
        // Добавляем действие по клику на кнопку
        button.addTarget(self, action: #selector(tap), for: .touchUpInside)
    }
    
  
    private func makeButton() {
        button.setTitle("Войти", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .gray
        button.setTitleColor(.black, for: .highlighted)
    }

    private func setupViews() {

        view.addSubview(label)
        view.addSubview(button)
        view.addSubview(log)
        view.addSubview(pass)
        setupConstraints()
    }
    
    
    // Настравиваем констрейнт
    private func setupConstraints() {
        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        
        
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 150),
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.widthAnchor.constraint(equalToConstant: view.frame.size.width/2),
            label.heightAnchor.constraint(equalToConstant: view.frame.size.width/8),
            
            button.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 300),
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.widthAnchor.constraint(equalToConstant: view.frame.size.width/2),
            button.heightAnchor.constraint(equalToConstant: view.frame.size.width/8),
            

        ])
    }

}

private extension ViewController {

    @objc func tap() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(ViewController2(), animated: true)
    }
    
}
