//
//  FriendView.swift
//  TestProject
//
//  Created by Stepan on 09.07.2023.
//

import UIKit

final class FriendView: UITableViewController {
    
    private let networkService = NetworkService()
    private var models: [Friend] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Friends"
        view.backgroundColor = Theme.currentTheme.backgroundColor
        tableView.backgroundColor = Theme.currentTheme.backgroundColor
        navigationController?.navigationBar.tintColor = Theme.currentTheme.textColor
        navigationController?.navigationBar.barTintColor = .red
        navigationItem.rightBarButtonItem = UIBarButtonItem(image:
            UIImage(systemName: "person"),
                                                            style: .plain,
                                                            target: self,
                                                            action: #selector(goProfile))
                                                            
        tableView.register(CellFriend.self, forCellReuseIdentifier: "FriendCell")
        networkService.getFriends { [weak self] friends in
            self?.models = friends
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        view.backgroundColor = Theme.currentTheme.backgroundColor
        tableView.backgroundColor = Theme.currentTheme.backgroundColor
        navigationController?.navigationBar.tintColor = Theme.currentTheme.textColor
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        models.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as? CellFriend else {
            return UITableViewCell()
        }
        let model = models[indexPath.row]
        cell.updateCell(model: model)
        return cell
        
    }
    
        
}
private extension FriendView {
    @objc func goProfile(){
        let animation = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name: .easeIn)
        animation.type = .moveIn
        animation.duration = 2
        navigationController?.view.layer.add(animation, forKey: nil)
        navigationController?.pushViewController(ProfileView(), animated: false)
    }
}
