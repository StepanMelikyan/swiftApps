//
//  Theme.swift
//  TestProject
//
//  Created by Stepan on 26.07.2023.
//

import UIKit

protocol SurfTheme {
    var backgroundColor: UIColor { get}
    var textColor: UIColor { get }
}

final class Theme {
    static var currentTheme: SurfTheme = GrayTheme()
}


final class GrayTheme: SurfTheme {
    var textColor: UIColor = .black
    
    var backgroundColor: UIColor = .lightGray
}

final class RedTheme: SurfTheme {
    var textColor: UIColor = .white
    
    var backgroundColor: UIColor = .red
}

final class GreenTheme: SurfTheme {
    var textColor: UIColor = .red
    
    var backgroundColor: UIColor = .green
}

