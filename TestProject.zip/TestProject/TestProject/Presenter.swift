//
//  Presenter.swift
//  TestProject
//
//  Created by Stepan on 26.07.2023.
//

final class Presenter{
    weak var viewController: ViewController?
    
    func updateScreen(){
        viewController?.updateScreen()
        
    }
}
