//
//  ThemsView.swift
//  TestProject
//
//  Created by Stepan on 26.07.2023.
//

import UIKit
final class ThemsView: UITableViewController {
    
    let button1: UIButton = {
        let button = UIButton()
        button.backgroundColor = GrayTheme().backgroundColor
        button.titleLabel?.textColor = GrayTheme().textColor
        button.layer.borderColor = UIColor.black.cgColor
        button.layer.borderWidth = 2
        return button
    }()
    
    let button2: UIButton = {
        let button = UIButton()
        button.backgroundColor = RedTheme().backgroundColor
        button.titleLabel?.textColor = RedTheme().textColor
        button.layer.borderColor = UIColor.black.cgColor
        button.layer.borderWidth = 2
        return button
    }()
    
    let button3: UIButton = {
        let button = UIButton()
        button.backgroundColor = GreenTheme().backgroundColor
        button.titleLabel?.textColor = GreenTheme().textColor
        button.layer.borderColor = UIColor.black.cgColor
        button.layer.borderWidth = 2
        return button
    }()
    
    
    
    
    
       override func viewDidLoad() {
           super.viewDidLoad()
           // Чтобы обратиться к вью контроллера сначала указываем вью, а затем свойство, которое хотим настроить
           view.backgroundColor = Theme.currentTheme.backgroundColor
           navigationController?.navigationBar.tintColor = Theme.currentTheme.textColor
           navigationController?.navigationBar.barTintColor = .red
           title = "Выберите тему"
           
           setupViews()
    
   
           // Добавляем действие по клику на кнопку
           button1.addTarget(self, action: #selector(tap1), for: .touchUpInside)
           button2.addTarget(self, action: #selector(tap2), for: .touchUpInside)
           button3.addTarget(self, action: #selector(tap3), for: .touchUpInside)
          
       }
   
       // 2 способ создания и настройки элемента. В одном классе используем только один способ. Не комбинируем.
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        view.backgroundColor = Theme.currentTheme.backgroundColor
        navigationController?.navigationBar.tintColor = Theme.currentTheme.textColor
    }
   
       private func setupViews() {
           // Обязательно добавляем сабвью на экран
           view.addSubview(button1)
           view.addSubview(button2)
           view.addSubview(button3)
      
   
           //  Констрейнты настраиваем только ПОСЛЕ того, как добавим сабвью на экран
           setupConstraints()
       }
   
   
       // Настравиваем констрейнт
       private func setupConstraints() {
          
           button1.translatesAutoresizingMaskIntoConstraints = false
           button2.translatesAutoresizingMaskIntoConstraints = false
           button3.translatesAutoresizingMaskIntoConstraints = false
         
   
           NSLayoutConstraint.activate([
     
               button1.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
               button1.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               button1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
               button1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
   
               button2.topAnchor.constraint(equalTo: button1.bottomAnchor, constant: 20),
               button2.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               button2.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
               button2.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
   
               button3.topAnchor.constraint(equalTo: button2.bottomAnchor, constant: 20),
               button3.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               button3.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
               button3.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30)
           ])
       }
}


private extension ThemsView {
    
    @objc func tap1() {
        Theme.currentTheme = GrayTheme()
        view.backgroundColor = Theme.currentTheme.backgroundColor
    }
    @objc func tap2() {
        Theme.currentTheme = RedTheme()
        view.backgroundColor = Theme.currentTheme.backgroundColor
        
    }
    @objc func tap3() {
        Theme.currentTheme = GreenTheme()
        view.backgroundColor = Theme.currentTheme.backgroundColor
        
    }
}
