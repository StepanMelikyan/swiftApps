//
//  ModelPhoto.swift
//  TestProject
//
//  Created by Stepan on 09.07.2023.
//
struct ModelPhoto: Decodable {
    var response: Photos
}

struct Photos: Decodable {
    var items: [Photo]
}

struct Photo: Decodable {
    var id: Int
    var text: String?
    var sizes: [Sizes]
}

struct Sizes: Codable {
    var url: String
}
