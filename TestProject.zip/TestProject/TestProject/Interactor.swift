//
//  Interactor.swift
//  TestProject
//
//  Created by Stepan on 26.07.2023.
//

final class Interactor{
    private var presenter: Presenter
    init(presenter: Presenter) {
        self.presenter = presenter
    }
    
    func updateScreen(){
        presenter.updateScreen()
    }
}
