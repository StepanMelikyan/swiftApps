//
//  Constants.swift
//  TestProject
//
//  Created by Stepan on 09.07.2023.
//

enum Constants {
    enum Identifier {
        static let photoCellIdentifier = "photoCell"
    }
}
