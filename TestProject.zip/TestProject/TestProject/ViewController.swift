

import UIKit

class ViewController: UIViewController {
    
    // 1 способ создания и настройки элемента
    private var label: UILabel = {
        let label = UILabel()
        label.text = "Авторизация"
        label.textAlignment = .center
        label.backgroundColor = .gray
        label.textColor = .white
        return label
    }()
    
    private var button1 = CustomButton(text: "Переход на TabBarController")
    private var button2 = CustomButton(text: "Перейти на  CollectionViewController")
    private var button3 = CustomButton(text: "Перейти на TableViewController")
    private var button4 = CustomButton(text: "Переход Frineds")
    private var button5 = CustomButton(text: "Перейти на Group")
    private var button6 = CustomButton(text: "Перейти на Photo")
    
    private var button = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Чтобы обратиться к вью контроллера сначала указываем вью, а затем свойство, которое хотим настроить
        view.backgroundColor = .white
        makeButton()
        setupViews()
        let ImageView = UIImageView(frame: CGRect(x: 168, y: 100, width: 50, height: 50))
        ImageView.image = UIImage(systemName: "globe")
        self.view.addSubview(ImageView)
        
        // Добавляем действие по клику на кнопку
        button1.addTarget(self, action: #selector(tap1), for: .touchUpInside)
        button3.addTarget(self, action: #selector(tap), for: .touchUpInside)
        button4.addTarget(self, action: #selector(tap3), for: .touchUpInside)
        button2.addTarget(self, action: #selector(tap2), for: .touchUpInside)
        button5.addTarget(self, action: #selector(tap5), for: .touchUpInside)
        button6.addTarget(self, action: #selector(tap6), for: .touchUpInside)
    }
    
    // 2 способ создания и настройки элемента. В одном классе используем только один способ. Не комбинируем.
    private func makeButton() {
        button.setTitle("Tap me!", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .blue
        button.setTitleColor(.red, for: .highlighted)
    }

    private func setupViews() {
        // Обязательно добавляем сабвью на экран
        view.addSubview(label)
        view.addSubview(button)
        view.addSubview(button1)
        view.addSubview(button2)
        view.addSubview(button3)
        view.addSubview(button4)
        view.addSubview(button5)
        view.addSubview(button6)
        
        //  Констрейнты настраиваем только ПОСЛЕ того, как добавим сабвью на экран
        setupConstraints()
    }
    
    
    // Настравиваем констрейнт
    private func setupConstraints() {
        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        button1.translatesAutoresizingMaskIntoConstraints = false
        button2.translatesAutoresizingMaskIntoConstraints = false
        button3.translatesAutoresizingMaskIntoConstraints = false
        button4.translatesAutoresizingMaskIntoConstraints = false
        button5.translatesAutoresizingMaskIntoConstraints = false
        button6.translatesAutoresizingMaskIntoConstraints = false
//        sq.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.widthAnchor.constraint(equalToConstant: view.frame.size.width/2),
            label.heightAnchor.constraint(equalToConstant: view.frame.size.width/8),
            
            button.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 500),
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            button.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            button1.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 20),
            button1.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            button1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
            button2.topAnchor.constraint(equalTo: button1.bottomAnchor, constant: 20),
            button2.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button2.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            button2.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
            button3.topAnchor.constraint(equalTo: button2.bottomAnchor, constant: 20),
            button3.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button3.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            button3.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
            button4.topAnchor.constraint(equalTo: button3.bottomAnchor, constant: 20),
            button4.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button4.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            button4.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
            button5.topAnchor.constraint(equalTo: button4.bottomAnchor, constant: 20),
            button5.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button5.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            button5.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
            button6.topAnchor.constraint(equalTo: button5.bottomAnchor, constant: 20),
            button6.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button6.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            button6.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
        ])
    }

}

private extension ViewController {

    @objc func tap() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(TableViewController(), animated: true)
        
    }
    @objc func tap2() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(CollectionViewController(collectionViewLayout: UICollectionViewFlowLayout()), animated: true)
        
    }
    @objc func tap1() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(TabBarController(), animated: true)
        
    }
    @objc func tap3() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(Frineds(), animated: true)
        
    }
    @objc func tap5() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(CellForGroup(collectionViewLayout: UICollectionViewFlowLayout()), animated: true)
        
    }
    
    @objc func tap6() {
        // Переходим на новый контроллер
        navigationController?.pushViewController(Photo(), animated: true)
        
    }
    
    
}
