//
//  ModelUser.swift
//  TestProject
//
//  Created by Stepan on 14.07.2023.
//

struct ModelUser: Decodable {
    var response: [User]
}

struct User: Decodable {
    var firstName: String?
    var lastName: String?
    var photo: String?
    
    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
        case photo = "photo_400_orig"
    }
}


