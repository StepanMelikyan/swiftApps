//
//  Asambler.swift
//  TestProject
//
//  Created by Stepan on 26.07.2023.
//

import UIKit
final class Asambler{
    static func build() -> UIViewController{
        let presenter = Presenter()
        let interactor = Interactor(presenter: presenter)
        let viewController = ViewController(interactor: interactor)
        presenter.viewController = viewController
        return viewController
    }
}
