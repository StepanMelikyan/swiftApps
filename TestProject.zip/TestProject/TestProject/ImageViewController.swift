

import UIKit

final class ImageViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray2
        view.addSubview(image)
        setupConstraints()
    }
    
    init(_ im: UIImage){
        super.init(nibName: nil, bundle: nil)
        image.image = im
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var image = UIImageView()
    
    private func setupConstraints() {
        image.translatesAutoresizingMaskIntoConstraints = false
        
        
        NSLayoutConstraint.activate([
            image.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            image.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            image.widthAnchor.constraint(equalToConstant: view.frame.size.width/2),
            image.heightAnchor.constraint(equalToConstant: view.frame.size.height/2)
            
        ])
    }
    
    
}
