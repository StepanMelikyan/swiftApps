

import Foundation

import UIKit

    

class TabBarController: UIViewController {
    func createTabBarController() {
            let bar = UITabBarController()
            bar.tabBar.tintColor = UIColor.white
//            bar.tabBar.backgroundColor = UIColor.black
            bar.tabBar.frame = CGRect(x: 50, y: 50, width: 50, height: 50)
            UITabBar.appearance().backgroundColor = .gray
            

            let firstVc = UIViewController()
            firstVc.title = "Friends"
            firstVc.tabBarItem = UITabBarItem.init(title: "Frineds", image: UIImage(systemName: "person.2.fill"), tag: 0)
            let secondVc = UIViewController()
            secondVc.title = "Group"
            secondVc.tabBarItem = UITabBarItem.init(title: "Group", image: UIImage(systemName: "person.3.sequence.fill"), tag: 0)
            let thirdVc = UIViewController()
            thirdVc.title = "Photos"
            thirdVc.tabBarItem = UITabBarItem.init(title: "Photos", image: UIImage(systemName: "photo.fill"), tag: 0)

            bar.viewControllers = [firstVc, secondVc, thirdVc]


            self.view.addSubview(bar.view)

        }

    override func viewDidLoad() {
          super.viewDidLoad()
          view.backgroundColor = .systemGray2
          createTabBarController()
    
      }
   

}




